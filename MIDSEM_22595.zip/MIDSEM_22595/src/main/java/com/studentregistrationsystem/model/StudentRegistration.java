package com.studentregistrationsystem.model;

public class StudentRegistration {
    private int registrationId;
    private String registrationCode;
    private String registrationDate;
    private int studentId;
    private int semesterId;
    private int departmentId;
    private int courseId;
    
    public int getRegistrationId() {
        return registrationId;
    }
    
    public void setRegistrationId(int registrationId) {
        this.registrationId = registrationId;
    }
    
    public String getRegistrationCode() {
        return registrationCode;
    }
    
    public void setRegistrationCode(String registrationCode) {
        this.registrationCode = registrationCode;
    }
    
    public String getRegistrationDate() {
        return registrationDate;
    }
    
    public void setRegistrationDate(String registrationDate) {
        this.registrationDate = registrationDate;
    }
    
    public int getStudentId() {
        return studentId;
    }
    
    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }
    
    public int getSemesterId() {
        return semesterId;
    }
    
    public void setSemesterId(semester) {
        this.semesterId = semester;
    }
    
    public int getDepartmentId() {
        return departmentId;
    }
    
    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

	public int getCourseId() {
		return courseId;
	
	}

	public void setCourseId(int int1) {
		this.courseId = courseId;
		
		
	}
}
