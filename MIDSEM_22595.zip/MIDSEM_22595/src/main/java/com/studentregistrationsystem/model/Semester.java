package com.studentregistrationsystem.model;

public class Semester {
    private int semesterId;
    private String semesterName;
    private String semesterStart;
    private String semesterEnd;
    
    public int getSemesterId() {
        return semesterId;
    }
    
    public void setSemesterId(int semesterId) {
        this.semesterId = semesterId;
    }
    
    public String getSemesterName() {
        return semesterName;
    }
    
    public void setSemesterName(String semesterName) {
        this.semesterName = semesterName;
    }
    
    public String getSemesterStart() {
        return semesterStart;
    }
    
    public void setSemesterStart(String semesterStart) {
        this.semesterStart = semesterStart;
    }
    
    public String getSemesterEnd() {
        return semesterEnd;
    }
    
    public void setSemesterEnd(String semesterEnd) {
        this.semesterEnd = semesterEnd;
    }
}
