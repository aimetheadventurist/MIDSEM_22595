package com.studentregistrationsystem.model;

public class CourseDefinition {
    private int courseDefinitionId;
    private String courseDefinitionCode;
    private String courseDefinitionDescription;
    private int courseId;
    
    public int getCourseDefinitionId() {
        return courseDefinitionId;
    }
    
    public void setCourseDefinitionId(int courseDefinitionId) {
        this.courseDefinitionId = courseDefinitionId;
    }
    
    public String getCourseDefinitionCode() {
        return courseDefinitionCode;
    }
    
    public void setCourseDefinitionCode(String courseDefinitionCode) {
        this.courseDefinitionCode = courseDefinitionCode;
    }
    
    public String getCourseDefinitionDescription() {
        return courseDefinitionDescription;
    }
    
    public void setCourseDefinitionDescription(String courseDefinitionDescription) {
        this.courseDefinitionDescription = courseDefinitionDescription;
    }
    
    public int getCourseId() {
        return courseId;
    }
    
    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }
}
