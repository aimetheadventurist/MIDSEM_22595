package com.studentregistrationsystem;

import com.studentregistrationsystem.view.StudentRegistrationSystemView;

public class StudentRegistrationSystemApplication {
    public static void main(String[] args) {
        StudentRegistrationSystemView view = new StudentRegistrationSystemView();
        view.displayMenu();
    }
}
