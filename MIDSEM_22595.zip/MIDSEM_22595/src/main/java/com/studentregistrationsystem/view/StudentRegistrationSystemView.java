package com.studentregistrationsystem.view;

import java.util.List;
import java.util.Scanner;

import com.studentregistrationsystem.dao.CourseDao;
import com.studentregistrationsystem.dao.CourseDefinitionDao;
import com.studentregistrationsystem.dao.DepartmentDao;
import com.studentregistrationsystem.dao.SemesterDao;
import com.studentregistrationsystem.dao.StudentDao;
import com.studentregistrationsystem.dao.StudentRegistrationDao;
import com.studentregistrationsystem.dao.TeacherDao;
import com.studentregistrationsystem.model.Course;
import com.studentregistrationsystem.model.Department;
import com.studentregistrationsystem.model.Semester;
import com.studentregistrationsystem.model.Student;

public class StudentRegistrationSystemView {

    private StudentDao studentDao;
    private CourseDao courseDao;
    private DepartmentDao departmentDao;
    private SemesterDao semesterDao;
    private StudentRegistrationDao studentRegistrationDao;
    private TeacherDao teacherDao;
    private CourseDefinitionDao courseDefinitionDao;

    public StudentRegistrationSystemView() {
        // Initialize DAO objects
        studentDao = new StudentDao(null);
        courseDao = new CourseDao(null);
        departmentDao = new DepartmentDao(null);
        semesterDao = new SemesterDao(null);
        studentRegistrationDao = new StudentRegistrationDao(null);
        teacherDao = new TeacherDao(null);
        courseDefinitionDao = new CourseDefinitionDao(null);
    }

    public void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("----- Student Registration System -----");
            System.out.println("1. Add Student");
            System.out.println("2. Add Course");
            System.out.println("3. Add Department");
            System.out.println("4. Add Semester");
            System.out.println("5. Add Teacher");
            System.out.println("6. Add Course Definition");
            System.out.println("7. Add Student Registration");
            System.out.println("8. List Students per Semester");
            System.out.println("9. List Students per Department and Semester");
            System.out.println("10. List Students per Course and Semester");
            System.out.println("11. List Courses per Department and Semester");
            System.out.println("12. List Courses per Student");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    addCourse();
                    break;
                case 3:
                    addDepartment();
                    break;
                case 4:
                    addSemester();
                    break;
                case 5:
                    addTeacher();
                    break;
                case 6:
                    addCourseDefinition();
                    break;
                case 7:
                    addStudentRegistration();
                    break;
                case 8:
                    listStudentsPerSemester();
                    break;
                case 9:
                    listStudentsPerDepartmentAndSemester();
                    break;
                case 10:
                    listStudentsPerCourseAndSemester();
                    break;
                case 11:
                    listCoursesPerDepartmentAndSemester();
                    break;
                case 12:
                    listCoursesPerStudent();
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 0);

        scanner.close();
    }

    private void addStudent() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter student details:");

        // Read student details from the user
        System.out.print("First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Last Name: ");
        String lastName = scanner.nextLine();

        System.out.print("Date of Birth: ");
        String dateOfBirth = scanner.nextLine();

        // Create a new Student object
        Student student = new Student();
        student.setFirstName(firstName);
        student.setLastName(lastName);
        student.setDateOfBirth(dateOfBirth);

        // Add the student to the database using the studentDao object
        studentDao.addStudent(student);

        System.out.println("Student added successfully!");
    }

    private void addCourse() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter course details:");

        // Read course details from the user
        System.out.print("Course Name: ");
        String courseName = scanner.nextLine();

        System.out.print("Course Code: ");
        String courseCode = scanner.nextLine();

        // Create a new Course object
        Course course = new Course();
        course.setCourseName(courseName);
        course.setCourseCode(courseCode);

        // Add the course to the database using the courseDao object
        courseDao.addCourse(course);

        System.out.println("Course added successfully!");
    }

    private void addDepartment() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter department details:");

        // Read department details from the user
        System.out.print("Department Name: ");
        String departmentName = scanner.nextLine();

        // Create a new Department object
        Department department = new Department();
        department.setDepartmentName(departmentName);

        // Add the department to the database using the departmentDao object
        departmentDao.addDepartment(department);

        System.out.println("Department added successfully!");
    }

    private void addSemester() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter semester details:");

        // Read semester details from the user
        System.out.print("Semester Name: ");
        String semesterName = scanner.nextLine();

        System.out.print("Semester Start: ");
        String semesterStart = scanner.nextLine();

        System.out.print("Semester End: ");
        String semesterEnd = scanner.nextLine();

        // Create a new Semester object
        Semester semester = new Semester();
        semester.setSemesterName(semesterName);
        semester.setSemesterStart(semesterStart);
        semester.setSemesterEnd(semesterEnd);

        // Add the semester to the database using the semesterDao object
        semesterDao.addSemester(semester);

        System.out.println("Semester added successfully!");
    }

    private void addTeacher() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter teacher details:");

        // Read teacher details from the user
        System.out.print("First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Last Name: ");
        String lastName = scanner.nextLine();

        System.out.print("Qualification: ");
        String qualification = scanner.nextLine();

        // Create a new Teacher object
        com.studentregistrationsystem.model.Teacher teacher = new com.studentregistrationsystem.model.Teacher();
        teacher.setFirstName(firstName);
        teacher.setLastName(lastName);
        teacher.setQualification(qualification);

        // Add the teacher to the database using the teacherDao object
        teacherDao.addTeacher(teacher);

        System.out.println("Teacher added successfully!");
    }

    private void addCourseDefinition() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter course definition details:");

        // Read course definition details from the user
        System.out.print("Course Definition Code: ");
        String courseDefinitionCode = scanner.nextLine();

        System.out.print("Course Definition Description: ");
        String courseDefinitionDescription = scanner.nextLine();

        // Create a new CourseDefinition object
        com.studentregistrationsystem.model.CourseDefinition courseDefinition = new com.studentregistrationsystem.model.CourseDefinition();
        courseDefinition.setCourseDefinitionCode(courseDefinitionCode);
        courseDefinition.setCourseDefinitionDescription(courseDefinitionDescription);

        // Add the course definition to the database using the courseDefinitionDao object
        courseDefinitionDao.addCourseDefinition(courseDefinition);

        System.out.println("Course Definition added successfully!");
    }

    private void addStudentRegistration() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter student registration details:");

        // Read student registration details from the user
        System.out.print("Student ID: ");
        int studentId = scanner.nextInt();

        System.out.print("Course ID: ");
        int courseId = scanner.nextInt();

        System.out.print("Semester ID: ");
        int semesterId = scanner.nextInt();

        // Create a new StudentRegistration object
        StudentRegistration studentRegistration = new StudentRegistration();
        studentRegistration.setStudentId(studentId);
        studentRegistration.setCourseId(courseId);
        studentRegistration.setSemesterId(semesterId);

        // Add the student registration to the database using the studentRegistrationDao object
        studentRegistrationDao.addStudentRegistration(studentRegistration);

        System.out.println("Student Registration added successfully!");
    }

    private void listStudentsPerSemester() {
        // Retrieve the list of students per semester from the database using the studentDao and semesterDao objects
        List<Student> students = studentDao.getStudentsPerSemester();

        // Display the list of students per semester
        System.out.println("Students per Semester:");
        for (Student student : students) {
            System.out.println("Student ID: " + student.getStudentId());
            System.out.println("First Name: " + student.getFirstName());
            System.out.println("Last Name: " + student.getLastName());
            System.out.println("Date of Birth: " + student.getDateOfBirth());
            System.out.println("------------------------");
        }
    }

    private void listStudentsPerDepartmentAndSemester() {
        // Retrieve the list of students per department and semester from the database using the studentDao, departmentDao, and semesterDao objects
        List<Student> students = studentDao.getStudentsPerDepartmentAndSemester();

        // Display the list of students per department and semester
        System.out.println("Students per Department and Semester:");
        for (Student student : students) {
            System.out.println("Student ID: " + student.getStudentId());
            System.out.println("First Name: " + student.getFirstName());
            System.out.println("Last Name: " + student.getLastName());
            System.out.println("Date of Birth: " + student.getDateOfBirth());
            System.out.println("------------------------");
        }
    }

    private void listStudentsPerCourseAndSemester() {
        // Retrieve the list of students per course and semester from the database using the studentDao, courseDao, and semesterDao objects
        List<Student> students = studentDao.getStudentsPerCourseAndSemester();

        // Display the list of students per course and semester
        System.out.println("Students per Course and Semester:");
        for (Student student : students) {
            System.out.println("Student ID: " + student.getStudentId());
            System.out.println("First Name: " + student.getFirstName());
            System.out.println("Last Name: " + student.getLastName());
            System.out.println("Date of Birth: " + student.getDateOfBirth());
            System.out.println("------------------------");
        }
    }

    private void listCoursesPerDepartmentAndSemester() {
        List<Course> courses = courseDao.getCoursesPerDepartmentAndSemester();

        // Display the list of courses per department and semester
        System.out.println("Courses per Department and Semester:");
        for (Course course : courses) {
            System.out.println("Course ID: " + course.getCourseId());
            System.out.println("Course Name: " + course.getCourseName());
            System.out.println("Course Code: " + course.getCourseCode());
            System.out.println("------------------------");
        }
    }

    private void listCoursesPerStudent() {

    	List<Course> courses = courseDao.getCoursesPerStudent();

        System.out.println("Courses per Student:");
        for (Course course : courses) {
            System.out.println("Course ID: " + course.getCourseId());
            System.out.println("Course Name: " + course.getCourseName());
            System.out.println("Course Code: " + course.getCourseCode());
            System.out.println("------------------------");
        }
    }

    public static void main(String[] args) {
        StudentRegistrationSystemView view = new StudentRegistrationSystemView();
        view.displayMenu();
    }
}