
package com.studentregistrationsystem.dao;

import com.studentregistrationsystem.model.StudentRegistration;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentRegistrationDao {
    private Connection connection;

    public StudentRegistrationDao(Connection connection) {
        this.connection = connection;
    }

    public void addStudentRegistration(StudentRegistration studentRegistration) {
        try {
            String query = "INSERT INTO student_registrations (student_id, course_id, semester_id) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, studentRegistration.getStudentId());
            statement.setInt(2, studentRegistration.getCourseId());
            statement.setInt(3, studentRegistration.getSemesterId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public StudentRegistration getStudentRegistrationById(int registrationId) {
        try {
            String query = "SELECT * FROM student_registrations WHERE registration_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, registrationId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                StudentRegistration studentRegistration = new StudentRegistration();
                studentRegistration.setRegistrationId(resultSet.getInt("registration_id"));
                studentRegistration.setStudentId(resultSet.getInt("student_id"));
                studentRegistration.setCourseId(resultSet.getInt("course_id"));
                studentRegistration.setSemesterId(resultSet.getInt("semester_id"));
                return studentRegistration;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateStudentRegistration(StudentRegistration studentRegistration) {
        try {
            String query = "UPDATE student_registrations SET student_id = ?, course_id = ?, semester_id = ? WHERE registration_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, studentRegistration.getStudentId());
            statement.setInt(2, studentRegistration.getCourseId());
            statement.setInt(3, studentRegistration.getSemesterId());
            statement.setInt(4, studentRegistration.getRegistrationId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteStudentRegistration(int registrationId) {
        try {
            String query = "DELETE FROM student_registrations WHERE registration_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, registrationId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<StudentRegistration> getAllStudentRegistrations() {
        List<StudentRegistration> studentRegistrations = new ArrayList<>();
        try {
            String query = "SELECT * FROM student_registrations";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                StudentRegistration studentRegistration = new StudentRegistration();
                studentRegistration.setRegistrationId(resultSet.getInt("registration_id"));
                studentRegistration.setStudentId(resultSet.getInt("student_id"));
                studentRegistration.setCourseId(resultSet.getInt("course_id"));
                studentRegistration.setSemesterId(resultSet.getInt("semester_id"));
                studentRegistrations.add(studentRegistration);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return studentRegistrations;
    }

	public List<StudentRegistration> StudentperSemester(StudentRegistration registration) {
		return null;
	}
}