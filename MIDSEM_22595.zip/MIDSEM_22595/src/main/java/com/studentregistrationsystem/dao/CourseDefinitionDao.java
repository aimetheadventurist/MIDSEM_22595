package com.studentregistrationsystem.dao;

import com.studentregistrationsystem.model.CourseDefinition;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDefinitionDao {
    private Connection connection;

    public CourseDefinitionDao(Connection connection) {
        this.connection = connection;
    }

    public void addCourseDefinition(CourseDefinition courseDefinition) {
        try {
            String query = "INSERT INTO course_definitions (course_definition_code, course_definition_description, course_id) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, courseDefinition.getCourseDefinitionCode());
            statement.setString(2, courseDefinition.getCourseDefinitionDescription());
            statement.setInt(3, courseDefinition.getCourseId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public CourseDefinition getCourseDefinitionById(int courseDefinitionId) {
        try {
            String query = "SELECT * FROM course_definitions WHERE course_definition_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, courseDefinitionId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                CourseDefinition courseDefinition = new CourseDefinition();
                courseDefinition.setCourseDefinitionId(resultSet.getInt("course_definition_id"));
                courseDefinition.setCourseDefinitionCode(resultSet.getString("course_definition_code"));
                courseDefinition.setCourseDefinitionDescription(resultSet.getString("course_definition_description"));
                courseDefinition.setCourseId(resultSet.getInt("course_id"));
                return courseDefinition;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateCourseDefinition(CourseDefinition courseDefinition) {
        try {
            String query = "UPDATE course_definitions SET course_definition_code = ?, course_definition_description = ?, course_id = ? WHERE course_definition_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, courseDefinition.getCourseDefinitionCode());
            statement.setString(2, courseDefinition.getCourseDefinitionDescription());
            statement.setInt(3, courseDefinition.getCourseId());
            statement.setInt(4, courseDefinition.getCourseDefinitionId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCourseDefinition(int courseDefinitionId) {
        try {
            String query = "DELETE FROM course_definitions WHERE course_definition_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, courseDefinitionId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<CourseDefinition> getAllCourseDefinitions() {
        List<CourseDefinition> courseDefinitions = new ArrayList<>();
        try {
            String query = "SELECT * FROM course_definitions";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                CourseDefinition courseDefinition = new CourseDefinition();
                courseDefinition.setCourseDefinitionId(resultSet.getInt("course_definition_id"));
                courseDefinition.setCourseDefinitionCode(resultSet.getString("course_definition_code"));
                courseDefinition.setCourseDefinitionDescription(resultSet.getString("course_definition_description"));
                courseDefinition.setCourseId(resultSet.getInt("course_id"));
                courseDefinitions.add(courseDefinition);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courseDefinitions;
    }
}