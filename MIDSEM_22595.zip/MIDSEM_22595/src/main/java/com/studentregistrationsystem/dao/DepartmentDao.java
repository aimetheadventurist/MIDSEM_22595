package com.studentregistrationsystem.dao;

import com.studentregistrationsystem.model.Department;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DepartmentDao {
    private Connection connection;

    public DepartmentDao(Connection connection) {
        this.connection = connection;
    }

    public void addDepartment(Department department) {
        try {
            String query = "INSERT INTO departments (department_name) VALUES (?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, department.getDepartmentName());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Department getDepartmentById(int departmentId) {
        try {
            String query = "SELECT * FROM departments WHERE department_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, departmentId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Department department = new Department();
                department.setDepartmentId(resultSet.getInt("department_id"));
                department.setDepartmentName(resultSet.getString("department_name"));
                return department;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateDepartment(Department department) {
        try {
            String query = "UPDATE departments SET department_name = ? WHERE department_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, department.getDepartmentName());
            statement.setInt(2, department.getDepartmentId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteDepartment(int departmentId) {
        try {
            String query = "DELETE FROM departments WHERE department_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, departmentId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Department> getAllDepartments() {
        List<Department> departments = new ArrayList<>();
        try {
            String query = "SELECT * FROM departments";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                Department department = new Department();
                department.setDepartmentId(resultSet.getInt("department_id"));
                department.setDepartmentName(resultSet.getString("department_name"));
                departments.add(department);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return departments;
    }
}