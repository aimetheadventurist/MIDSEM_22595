
package com.studentregistrationsystem.dao;

import com.studentregistrationsystem.model.Course;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDao {
    private Connection connection;

    public CourseDao(Connection connection) {
        this.connection = connection;
    }

    public void addCourse(Course course) {
        try {
            String query = "INSERT INTO courses (course_name, course_code, semester_id, department_id) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, course.getCourseName());
            statement.setString(2, course.getCourseCode());
            statement.setInt(3, course.getSemesterId());
            statement.setInt(4, course.getDepartmentId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Course getCourseById(int courseId) {
        try {
            String query = "SELECT * FROM courses WHERE course_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, courseId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Course course = new Course();
                course.setCourseId(resultSet.getInt("course_id"));
                course.setCourseName(resultSet.getString("course_name"));
                course.setCourseCode(resultSet.getString("course_code"));
                course.setSemesterId(resultSet.getInt("semester_id"));
                course.setDepartmentId(resultSet.getInt("department_id"));
                return course;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateCourse(Course course) {
        try {
            String query = "UPDATE courses SET course_name = ?, course_code = ?, semester_id = ?, department_id = ? WHERE course_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, course.getCourseName());
            statement.setString(2, course.getCourseCode());
            statement.setInt(3, course.getSemesterId());
            statement.setInt(4, course.getDepartmentId());
            statement.setInt(5, course.getCourseId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCourse(int courseId) {
        try {
            String query = "DELETE FROM courses WHERE course_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, courseId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Course> getAllCourses() {
        List<Course> courses = new ArrayList<>();
        try {
            String query = "SELECT * FROM courses";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                Course course = new Course();
                course.setCourseId(resultSet.getInt("course_id"));
                course.setCourseName(resultSet.getString("course_name"));
                course.setCourseCode(resultSet.getString("course_code"));
                course.setSemesterId(resultSet.getInt("semester_id"));
                course.setDepartmentId(resultSet.getInt("department_id"));
                courses.add(course);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }

	public List<Course> getCoursesPerDepartmentAndSemester() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Course> getCoursesPerStudent() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Course> getCoursesPerDepartmentAndSemester() {
		// TODO Auto-generated method stub
		return null;
	}
}
