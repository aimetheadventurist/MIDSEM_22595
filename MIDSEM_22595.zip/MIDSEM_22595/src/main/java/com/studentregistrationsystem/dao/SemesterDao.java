
package com.studentregistrationsystem.dao;

import com.studentregistrationsystem.model.Semester;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SemesterDao {
    private Connection connection;

    public SemesterDao(Connection connection) {
        this.connection = connection;
    }

    public void addSemester(Semester semester) {
        try {
            String query = "INSERT INTO semesters (semester_name, semester_start, semester_end) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, semester.getSemesterName());
            statement.setString(2, semester.getSemesterStart());
            statement.setString(3, semester.getSemesterEnd());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Semester getSemesterById(int semesterId) {
        try {
            String query = "SELECT * FROM semesters WHERE semester_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, semesterId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Semester semester = new Semester();
                semester.setSemesterId(resultSet.getInt("semester_id"));
                semester.setSemesterName(resultSet.getString("semester_name"));
                semester.setSemesterStart(resultSet.getString("semester_start"));
                semester.setSemesterEnd(resultSet.getString("semester_end"));
                return semester;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateSemester(Semester semester) {
        try {
            String query = "UPDATE semesters SET semester_name = ?, semester_start = ?, semester_end = ? WHERE semester_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, semester.getSemesterName());
            statement.setString(2, semester.getSemesterStart());
            statement.setString(3, semester.getSemesterEnd());
            statement.setInt(4, semester.getSemesterId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteSemester(int semesterId) {
        try {
            String query = "DELETE FROM semesters WHERE semester_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, semesterId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Semester> getAllSemesters() {
        List<Semester> semesters = new ArrayList<>();
        try {
            String query = "SELECT * FROM semesters";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                Semester semester = new Semester();
                semester.setSemesterId(resultSet.getInt("semester_id"));
                semester.setSemesterName(resultSet.getString("semester_name"));
                semester.setSemesterStart(resultSet.getString("semester_start"));
                semester.setSemesterEnd(resultSet.getString("semester_end"));
                semesters.add(semester);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return semesters;
    }
}