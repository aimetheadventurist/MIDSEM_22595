package com.studentregistrationsystem.dao;

import com.studentregistrationsystem.model.Teacher;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TeacherDao {
    private Connection connection;

    public TeacherDao(Connection connection) {
        this.connection = connection;
    }

    public void addTeacher(Teacher teacher) {
        try {
            String query = "INSERT INTO teachers (first_name, last_name, qualification, course_id) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, teacher.getFirstName());
            statement.setString(2, teacher.getLastName());
            statement.setString(3, teacher.getQualification());
            statement.setInt(4, teacher.getCourseId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Teacher getTeacherById(int teacherId) {
        try {
            String query = "SELECT * FROM teachers WHERE teacher_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, teacherId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Teacher teacher = new Teacher();
                teacher.setTeacherId(resultSet.getInt("teacher_id"));
                teacher.setFirstName(resultSet.getString("first_name"));
                teacher.setLastName(resultSet.getString("last_name"));
                teacher.setQualification(resultSet.getString("qualification"));
                teacher.setCourseId(resultSet.getInt("course_id"));
                return teacher;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateTeacher(Teacher teacher) {
        try {
            String query = "UPDATE teachers SET first_name = ?, last_name = ?, qualification = ?, course_id = ? WHERE teacher_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, teacher.getFirstName());
            statement.setString(2, teacher.getLastName());
            statement.setString(3, teacher.getQualification());
            statement.setInt(4, teacher.getCourseId());
            statement.setInt(5, teacher.getTeacherId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteTeacher(int teacherId) {
        try {
            String query = "DELETE FROM teachers WHERE teacher_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, teacherId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Teacher> getAllTeachers() {
        List<Teacher> teachers = new ArrayList<>();
        try {
            String query = "SELECT * FROM teachers";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                Teacher teacher = new Teacher();
                teacher.setTeacherId(resultSet.getInt("teacher_id"));
                teacher.setFirstName(resultSet.getString("first_name"));
                teacher.setLastName(resultSet.getString("last_name"));
                teacher.setQualification(resultSet.getString("qualification"));
                teacher.setCourseId(resultSet.getInt("course_id"));
                teachers.add(teacher);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teachers;
    }
}