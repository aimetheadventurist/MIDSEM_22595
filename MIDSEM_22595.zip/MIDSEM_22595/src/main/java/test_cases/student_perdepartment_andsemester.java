package test_cases;

import com.studentregistrationsystem.dao.*;
import com.studentregistrationsystem.model.*;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class student_perdepartment_andsemester {
		    
	    public void Student_SemesterandDepartment(){
	        Semester semester=new Semester();
	        semester.setSemester_id(1);
	        AcademicUnit academicUnit=new AcademicUnit();
	        academicUnit.setId(8);
	        Course course=new Course();
	        course.setAcademicUnit(academicUnit);
	        course.setSemester(semester);
	        com.studentregistrationsystem.dao.CourseDao dao=new CourseDao();
	        List<com.studentregistrationsystem.model.Course> Courselist =dao. departmentandSemester(course);
	        //Test if registrationslist is not empty 
		assertNotNull(Courselist);
		assertTrue(Courselist.size() > 0);
	    }

	}


}
