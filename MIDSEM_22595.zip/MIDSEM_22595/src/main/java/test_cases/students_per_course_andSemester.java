package test_cases;
import com.studentregistrationsystem.dao.*;
import com.studentregistrationsystem.model.*;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class students_per_course_andSemester {
	
	


    
     @Test
    public void Student_Semester(){
        Semester semester=new Semester();
        semester.setSemester_id(1);
        
        Course course =new Course();
        course.setId(1);        
       
        StudentCourse studentcourse=new StudentCourse();
        studentcourse.setSemestersdata1(semester);
        studentcourse.setStudentCourse(course);
         StudentcoursesDao dao=new StudentcoursesDao();
        List<StudentCourse> Studentlist =dao.StudentpercourseandSemester(studentcourse);
        //Test if Studentlistlist is not empty 
	assertNotNull( Studentlist);
	assertTrue( Studentlist.size() > 0);
    }

}


}
