package test_cases;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import com.studentregistrationsystem.dao.*;
import com.studentregistrationsystem.model.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;



public class listing_students_per_semester<Semester> {
	
	    public void Student_Semester(){
	        Semester semester=new Semester();
	        semester.setSemesterId(1);
	        
	        StudentRegistration registration=new StudentRegistration();
	        registration.setSemesterId();
	        
	        StudentRegistrationDao dao=new StudentRegistrationDao(null);
	        List<StudentRegistration> registrationslist =dao.StudentperSemester(registration);

	        assertNotNull(registrationslist);
		assertTrue(registrationslist.size() > 0);
	    }

	}


