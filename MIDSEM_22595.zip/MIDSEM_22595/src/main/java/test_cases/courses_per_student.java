package test_cases;


import com.studentregistrationsystem.dao.*;
import com.studentregistrationsystem.model.*;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class courses_per_student {
	
	 @Test
	    public void Student_Semester(){
	        
	        Student student=new Student();
	        student.setStudent_id("12345");
	       
	        StudentCourse course=new StudentCourse();
	        course.setStudentRegistration(student);
	        StudentcoursesDao dao=new StudentcoursesDao();
	        List<StudentCourse> Studentcourselist =dao.CourseperStudent(course);

	    assertNotNull(Studentcourselist);
		assertTrue(Studentcourselist.size() > 0);
	    }
	

}
